This task is a part of the Server-side Development with NodeJS, Express and MongoDB course on Coursera, Full Stack Web and Multiplatform Mobile App Development Specialization.
